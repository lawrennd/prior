
% PRIORTOOLBOXES Load in the relevant toolboxes for kern.
%
%	Description:
%	% 	priorToolboxes.m SVN version 325
% 	last update 2009-04-17T21:06:01.000000Z
importLatest('optimi');
importLatest('ndlutil');
