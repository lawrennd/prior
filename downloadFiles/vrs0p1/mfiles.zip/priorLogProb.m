function l = priorLogProb(prior, x)

% PRIORLOGPROB Log probability of Gaussian prior.
%
% l = priorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





% Compute log prior
l = feval([prior.type 'PriorLogProb'], prior, x);
