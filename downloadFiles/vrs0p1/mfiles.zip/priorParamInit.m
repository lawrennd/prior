function prior = priorParamInit(prior)

% PRIORPARAMINIT Prior model's parameter initialisation.
%
% prior = priorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





prior = feval([prior.type 'PriorParamInit'], prior);
