function [params, names] = gaussianPriorExtractParam(prior)

% GAUSSIANPRIOREXTRACTPARAM Extract params from Gaussian prior structure.
%
% [params, names] = gaussianPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.1





params = prior.precision;
if nargout > 1
  names = {'Gaussian precision'};
end