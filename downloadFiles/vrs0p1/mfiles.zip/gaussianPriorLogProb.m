function l = gaussianPriorLogProb(prior, x)

% GAUSSIANPRIORLOGPROB Log probability of Gaussian prior.
%
% l = gaussianPriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.1





% Compute log prior
l = -.5*(prior.precision*x*x' + log(2*pi) - log(prior.precision));
