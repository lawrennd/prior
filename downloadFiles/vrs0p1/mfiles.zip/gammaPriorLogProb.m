function l = gammaPriorLogProb(prior, x)

% GAMMAPRIORLOGPROB Log probability of Gamma prior.
%
% l = gammaPriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





% Compute log prior
D = length(x);
l = D*prior.a*log(prior.b)-D*gammaln(prior.a)+(prior.a-1)*sum(log(x))-prior.b*sum(x);
