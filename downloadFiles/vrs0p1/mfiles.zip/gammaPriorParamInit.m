function prior = gammaPriorParamInit(prior)

% GAMMAPRIORPARAMINIT Gamma prior model's parameter initialisation.
%
% prior = gammaPriorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





prior.a = 1e-6;
prior.b = 1e-6;

prior.transforms.index = [1 2];
prior.transforms.type = 'negLogLogit';
prior.nParams = 2;
