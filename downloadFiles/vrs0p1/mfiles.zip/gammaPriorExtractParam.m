function [params, names] = gammaPriorExtractParam(prior)

% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
%
% [params, names] = gammaPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





params = [prior.a prior.b];
if nargout > 1
  names = {'gamma a', 'gamma b'};
end