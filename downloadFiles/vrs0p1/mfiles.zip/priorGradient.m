function g = priorGradient(prior, params)

% PRIORGRADIENTPARAM Gradient of the prior with respect to its variables
%
% g = priorGradient(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1




g = feval([prior.type 'PriorGradient'], prior, params);