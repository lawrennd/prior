function g = gammaPriorGradient(prior, x)

% GAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
%
% g = gammaPriorGradient(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





% Compute gradient of prior
g = (prior.a-1)./x-prior.b;
