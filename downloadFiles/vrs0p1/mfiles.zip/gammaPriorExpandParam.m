function prior = gammaPriorExpandParam(prior, params)

% GAMMAPRIOREXPANDPARAM Expand gamma prior structure from params.
%
% prior = gammaPriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version , 
% PRIOR toolbox version 0.1





prior.a = params(1);
prior.b = params(2);
