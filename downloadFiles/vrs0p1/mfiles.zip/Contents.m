% PRIOR toolbox
% Version 0.1 Saturday, June 12, 2004 at 14:13:19
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% GAMMAPRIOREXPANDPARAM Expand gamma prior structure from params.
% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
% GAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% GAMMAPRIORLOGPROB Log probability of Gamma prior.
% GAMMAPRIORPARAMINIT Gamma prior model's parameter initialisation.
% SIGMOIDTRANSFORM Constrains a parameter to be between 0 and 1.
% GAUSSIANPRIOREXPANDPARAM Expand Gaussian prior structure from param vector.
% GAUSSIANPRIOREXTRACTPARAM Extract params from Gaussian prior structure.
% GAUSSIANPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% GAUSSIANPRIORLOGPROB Log probability of Gaussian prior.
% GAUSSIANPRIORPARAMINIT Gaussian prior model's parameter initialisation.
% INVGAMMAPRIOREXPANDPARAM Expand inverse gamma prior structure from params.
% INVGAMMAPRIOREXTRACTPARAM Extract params from inverse gamma prior structure.
% INVGAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% INVGAMMAPRIORLOGPROB Log probability of inverse gamma prior.
% INVGAMMAPRIORPARAMINIT Inverse gamma prior model's parameter initialisation.
% PRIOREXPANDPARAM Expand the prior model's parameters from params vector.
% PRIOREXTRACTPARAM Extract the prior model's parameters.
% PRIORGRADIENTPARAM Gradient of the prior with respect to its variables
% PRIORLOGPROB Log probability of Gaussian prior.
% PRIORPARAMINIT Prior model's parameter initialisation.
% PRIORTEST Run some tests on the specified prior.
