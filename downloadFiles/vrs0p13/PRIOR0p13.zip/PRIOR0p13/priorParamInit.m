function prior = priorParamInit(prior)

% PRIORPARAMINIT Prior model's parameter initialisation.
%
% prior = priorParamInit(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% priorParamInit.m version 1.2



prior = feval([prior.type 'PriorParamInit'], prior);
