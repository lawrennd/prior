function l = priorLogProb(prior, x)

% PRIORLOGPROB Log probability of Gaussian prior.
%
% l = priorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% priorLogProb.m version 1.3



% Compute log prior
fhandle = str2func([prior.type 'PriorLogProb']);
l = fhandle(prior, x);
