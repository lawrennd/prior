function [params, names] = invgammaPriorExtractParam(prior)

% INVGAMMAPRIOREXTRACTPARAM Extract params from inverse gamma prior structure.
%
% [params, names] = invgammaPriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% invgammaPriorExtractParam.m version 1.2





params = [prior.a prior.b];
if nargout > 1
  names = {'inv gamma a', 'inv gamma b'};
end