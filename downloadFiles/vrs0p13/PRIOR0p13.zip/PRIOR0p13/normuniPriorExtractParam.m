function [params, names] = normuniPriorExtractParam(prior)

% NORMUNIPRIOREXTRACTPARAM Extract params from normal uniform prior structure.
%
% [params, names] = normuniPriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% normuniPriorExtractParam.m version 1.1



params = [prior.sigma prior.width];
if nargout > 1
  names = {'Distribution scale', 'Uniform width'};
end