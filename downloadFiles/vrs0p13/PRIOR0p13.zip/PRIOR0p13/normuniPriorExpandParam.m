function prior = normuniPriorExpandParam(prior, params)

% NORMUNIPRIOREXPANDPARAM Expand Normal uniform prior structure from param vector.
%
% prior = normuniPriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% normuniPriorExpandParam.m version 1.1



prior.sigma = params(1);
prior.width = params(2);
