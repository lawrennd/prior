function prior = gaussianPriorExpandParam(prior, params)

% GAUSSIANPRIOREXPANDPARAM Expand Gaussian prior structure from param vector.
%
% prior = gaussianPriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussianPriorExpandParam.m version 1.3



prior.precision = params(1);
