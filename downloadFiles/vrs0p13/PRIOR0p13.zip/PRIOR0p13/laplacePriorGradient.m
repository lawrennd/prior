function g = laplacePriorGradient(prior, x)

% LAPLACEPRIORGRADIENT Gradient wrt x of the log Laplace prior.
%
% g = laplacePriorGradient(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% laplacePriorGradient.m version 1.1



% Compute gradient of prior
g = -prior.precision*sign(x);
