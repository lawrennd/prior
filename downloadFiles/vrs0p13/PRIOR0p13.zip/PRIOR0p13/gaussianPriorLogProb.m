function l = gaussianPriorLogProb(prior, x)

% GAUSSIANPRIORLOGPROB Log probability of Gaussian prior.
%
% l = gaussianPriorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussianPriorLogProb.m version 1.3



% Compute log prior
l = -.5*(prior.precision*x*x' + log(2*pi) - log(prior.precision));
