function prior = laplacePriorExpandParam(prior, params)

% LAPLACEPRIOREXPANDPARAM Expand Laplace prior structure from param vector.
%
% prior = laplacePriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% laplacePriorExpandParam.m version 1.1



prior.precision = params(1);
