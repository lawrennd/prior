function prior = priorCreate(type)

% PRIORCREATE Create a prior structure given a type.
%
% prior = priorCreate(type)
%

% Copyright (c) 2005 Neil D. Lawrence
% priorCreate.m version 1.1



prior.type = type;
prior = priorParamInit(prior);
