function l = gammaPriorLogProb(prior, x)

% GAMMAPRIORLOGPROB Log probability of Gamma prior.
%
% l = gammaPriorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% gammaPriorLogProb.m version 1.2



% Compute log prior
D = length(x);
l = D*prior.a*log(prior.b)-D*gammaln(prior.a)+(prior.a-1)*sum(log(x))-prior.b*sum(x);
