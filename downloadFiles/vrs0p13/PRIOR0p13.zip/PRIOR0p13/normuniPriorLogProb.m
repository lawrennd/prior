function l = normuniPriorLogProb(prior, x)

% NORMUNIPRIORLOGPROB Log probability of a normal uniform.
%
% l = normuniPriorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% normuniPriorLogProb.m version 1.1



% Compute log prior
u = (x+prior.width/2)/prior.sigma;
uprime = u - prior.width/prior.sigma;
l = sum(- log(prior.width) - lnDiffCumGaussian(u, uprime));


