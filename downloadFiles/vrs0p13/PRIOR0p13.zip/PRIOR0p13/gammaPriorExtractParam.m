function [params, names] = gammaPriorExtractParam(prior)

% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
%
% [params, names] = gammaPriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% gammaPriorExtractParam.m version 1.2



params = [prior.a prior.b];
if nargout > 1
  names = {'gamma a', 'gamma b'};
end