function prior = gammaPriorExpandParam(prior, params)

% GAMMAPRIOREXPANDPARAM Expand gamma prior structure from params.
%
% prior = gammaPriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% gammaPriorExpandParam.m version 1.2



prior.a = params(1);
prior.b = params(2);
