% PRIOR toolbox
% Version 0.12 Monday, July 12, 2004 at 19:06:09
% Copyright (c) 2004 Neil D. Lawrence
% 
% GAMMAPRIOREXPANDPARAM Expand gamma prior structure from params.
% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
% GAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% GAMMAPRIORLOGPROB Log probability of Gamma prior.
% GAMMAPRIORPARAMINIT Gamma prior model's parameter initialisation.
% GAUSSIANPRIOREXPANDPARAM Expand Gaussian prior structure from param vector.
% GAUSSIANPRIOREXTRACTPARAM Extract params from Gaussian prior structure.
% GAUSSIANPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% GAUSSIANPRIORLOGPROB Log probability of Gaussian prior.
% GAUSSIANPRIORPARAMINIT Gaussian prior model's parameter initialisation.
% INVGAMMAPRIOREXPANDPARAM Expand inverse gamma prior structure from params.
% INVGAMMAPRIOREXTRACTPARAM Extract params from inverse gamma prior structure.
% INVGAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
% INVGAMMAPRIORLOGPROB Log probability of inverse gamma prior.
% INVGAMMAPRIORPARAMINIT Inverse gamma prior model's parameter initialisation.
% LAPLACEPRIOREXPANDPARAM Expand Laplace prior structure from param vector.
% LAPLACEPRIOREXTRACTPARAM Extract params from Laplace prior structure.
% LAPLACEPRIORGRADIENT Gradient wrt x of the log Laplace prior.
% LAPLACEPRIORLOGPROB Log probability of Laplace prior.
% LAPLACEPRIORPARAMINIT Laplace prior model's parameter initialisation.
% NORMUNIPRIOREXPANDPARAM Expand Normal uniform prior structure from param vector.
% NORMUNIPRIOREXTRACTPARAM Extract params from normal uniform prior structure.
% NORMUNIPRIORGRADIENT Gradient wrt x of the log normal uniform prior.
% NORMUNIPRIORLOGPROB Log probability of a normal uniform.
% NORMUNIPRIORPARAMINIT Normal uniform prior model's parameter initialisation.
% PRIOREXPANDPARAM Expand the prior model's parameters from params vector.
% PRIOREXTRACTPARAM Extract the prior model's parameters.
% PRIORGRADIENT Gradient of the prior with respect to its variables
% PRIORLOGPROB Log probability of Gaussian prior.
% PRIORPARAMINIT Prior model's parameter initialisation.
% PRIORTEST Run some tests on the specified prior.
