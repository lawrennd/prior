function g = priorGradient(prior, params)

% PRIORGRADIENT Gradient of the prior with respect to its variables
%
% g = priorGradient(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 23 09:21:56 2004
% PRIOR toolbox version 0.12



g = feval([prior.type 'PriorGradient'], prior, params);