function prior = priorParamInit(prior)

% PRIORPARAMINIT Prior model's parameter initialisation.
%
% prior = priorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 30 09:14:48 2004
% PRIOR toolbox version 0.12



prior = feval([prior.type 'PriorParamInit'], prior);
