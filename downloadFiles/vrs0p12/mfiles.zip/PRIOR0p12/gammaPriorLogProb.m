function l = gammaPriorLogProb(prior, x)

% GAMMAPRIORLOGPROB Log probability of Gamma prior.
%
% l = gammaPriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 30 09:14:30 2004
% PRIOR toolbox version 0.12



% Compute log prior
D = length(x);
l = D*prior.a*log(prior.b)-D*gammaln(prior.a)+(prior.a-1)*sum(log(x))-prior.b*sum(x);
