function l = gaussianPriorLogProb(prior, x)

% GAUSSIANPRIORLOGPROB Log probability of Gaussian prior.
%
% l = gaussianPriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 09:05:21 2004
% PRIOR toolbox version 0.12



% Compute log prior
l = -.5*(prior.precision*x*x' + log(2*pi) - log(prior.precision));
