function prior = gammaPriorExpandParam(prior, params)

% GAMMAPRIOREXPANDPARAM Expand gamma prior structure from params.
%
% prior = gammaPriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 30 09:14:14 2004
% PRIOR toolbox version 0.12



prior.a = params(1);
prior.b = params(2);
