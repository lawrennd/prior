function g = normuniPriorGradient(prior, x)

% NORMUNIPRIORGRADIENT Gradient wrt x of the log normal uniform prior.
%
% g = normuniPriorGradient(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 14:41:29 2004
% PRIOR toolbox version 0.12



% Compute gradient of prior
u = (x+prior.width/2)/prior.sigma;
uprime = u - prior.width/prior.sigma;

B1 = gaussOverDiffCumGaussian(u, uprime, 1);
B2 = gaussOverDiffCumGaussian(u, uprime, 2);
g = (B1-B2)/prior.sigma;

