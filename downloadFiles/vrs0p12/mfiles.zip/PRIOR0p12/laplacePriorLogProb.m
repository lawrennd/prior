function l = laplacePriorLogProb(prior, x)

% LAPLACEPRIORLOGPROB Log probability of Laplace prior.
%
% l = laplacePriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 29 12:21:40 2004
% PRIOR toolbox version 0.12



% Compute log prior
l = -prior.precision*sum(abs(x)) - log(2) + log(prior.precision);
