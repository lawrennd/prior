function prior = invgammaPriorParamInit(prior)

% INVGAMMAPRIORPARAMINIT Inverse gamma prior model's parameter initialisation.
%
% prior = invgammaPriorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.12





prior.a = 1e-6;
prior.b = 1e-6;

prior.transforms.index = [1 2];
prior.transforms.type = 'negLogLogit';
prior.nParams = 2;
