function prior = laplacePriorExpandParam(prior, params)

% LAPLACEPRIOREXPANDPARAM Expand Laplace prior structure from param vector.
%
% prior = laplacePriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 29 12:16:50 2004
% PRIOR toolbox version 0.12



prior.precision = params(1);
