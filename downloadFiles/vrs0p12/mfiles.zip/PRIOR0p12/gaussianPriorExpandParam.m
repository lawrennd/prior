function prior = gaussianPriorExpandParam(prior, params)

% GAUSSIANPRIOREXPANDPARAM Expand Gaussian prior structure from param vector.
%
% prior = gaussianPriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Tue Jun 29 12:16:22 2004
% PRIOR toolbox version 0.12



prior.precision = params(1);
