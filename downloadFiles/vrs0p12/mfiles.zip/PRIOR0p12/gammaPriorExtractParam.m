function [params, names] = gammaPriorExtractParam(prior)

% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
%
% [params, names] = gammaPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 30 09:14:02 2004
% PRIOR toolbox version 0.12



params = [prior.a prior.b];
if nargout > 1
  names = {'gamma a', 'gamma b'};
end