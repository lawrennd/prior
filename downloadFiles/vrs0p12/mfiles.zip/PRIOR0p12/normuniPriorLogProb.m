function l = normuniPriorLogProb(prior, x)

% NORMUNIPRIORLOGPROB Log probability of a normal uniform.
%
% l = normuniPriorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 14:36:02 2004
% PRIOR toolbox version 0.12



% Compute log prior
u = (x+prior.width/2)/prior.sigma;
uprime = u - prior.width/prior.sigma;
l = sum(- log(prior.width) - lnDiffCumGaussian(u, uprime));


