function prior = laplacePriorParamInit(prior)

% LAPLACEPRIORPARAMINIT Laplace prior model's parameter initialisation.
%
% prior = laplacePriorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 09:10:28 2004
% PRIOR toolbox version 0.12



prior.precision = 1;

prior.transforms.index = [1];
prior.transforms.type = 'negLogLogit';
prior.nParams = 1;
