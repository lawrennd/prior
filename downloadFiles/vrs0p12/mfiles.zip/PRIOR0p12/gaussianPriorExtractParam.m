function [params, names] = gaussianPriorExtractParam(prior)

% GAUSSIANPRIOREXTRACTPARAM Extract params from Gaussian prior structure.
%
% [params, names] = gaussianPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Wed Jun 30 08:59:07 2004
% PRIOR toolbox version 0.12



params = prior.precision;
if nargout > 1
  names = {'Gaussian precision'};
end