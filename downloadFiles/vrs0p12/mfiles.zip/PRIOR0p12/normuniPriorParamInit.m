function prior = normuniPriorParamInit(prior)

% NORMUNIPRIORPARAMINIT Normal uniform prior model's parameter initialisation.
%
% prior = normuniPriorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 15:14:35 2004
% PRIOR toolbox version 0.12



prior.sigma = 0.1;
prior.width = 2;
prior.transforms.index = [1 2];
prior.transforms.type = 'negLogLogit';
prior.nParams = 2;
