function [params, names] = laplacePriorExtractParam(prior)

% LAPLACEPRIOREXTRACTPARAM Extract params from Laplace prior structure.
%
% [params, names] = laplacePriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 29 12:17:31 2004
% PRIOR toolbox version 0.12



params = prior.precision;
if nargout > 1
  names = {'Laplace precision'};
end