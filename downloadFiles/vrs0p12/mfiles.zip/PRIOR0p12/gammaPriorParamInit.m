function prior = gammaPriorParamInit(prior)

% GAMMAPRIORPARAMINIT Gamma prior model's parameter initialisation.
%
% prior = gammaPriorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 30 09:14:23 2004
% PRIOR toolbox version 0.12



prior.a = 1e-6;
prior.b = 1e-6;

prior.transforms.index = [1 2];
prior.transforms.type = 'negLogLogit';
prior.nParams = 2;
