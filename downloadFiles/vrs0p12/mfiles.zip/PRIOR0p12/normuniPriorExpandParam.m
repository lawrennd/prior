function prior = normuniPriorExpandParam(prior, params)

% NORMUNIPRIOREXPANDPARAM Expand Normal uniform prior structure from param vector.
%
% prior = normuniPriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 09:04:35 2004
% PRIOR toolbox version 0.12



prior.sigma = params(1);
prior.width = params(2);
