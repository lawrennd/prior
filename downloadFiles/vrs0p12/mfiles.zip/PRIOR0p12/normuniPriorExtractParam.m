function [params, names] = normuniPriorExtractParam(prior)

% NORMUNIPRIOREXTRACTPARAM Extract params from normal uniform prior structure.
%
% [params, names] = normuniPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 30 09:04:18 2004
% PRIOR toolbox version 0.12



params = [prior.sigma prior.width];
if nargout > 1
  names = {'Distribution scale', 'Uniform width'};
end