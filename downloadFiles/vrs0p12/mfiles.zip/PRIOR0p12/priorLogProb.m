function l = priorLogProb(prior, x)

% PRIORLOGPROB Log probability of Gaussian prior.
%
% l = priorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Mon Jun 21 09:05:11 2004
% PRIOR toolbox version 0.12



% Compute log prior
l = feval([prior.type 'PriorLogProb'], prior, x);
