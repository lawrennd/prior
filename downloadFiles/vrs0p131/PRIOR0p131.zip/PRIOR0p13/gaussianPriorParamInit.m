function prior = gaussianPriorParamInit(prior)

% GAUSSIANPRIORPARAMINIT Gaussian prior model's parameter initialisation.
%
% prior = gaussianPriorParamInit(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussianPriorParamInit.m version 1.3



prior.precision = 1;

prior.transforms.index = [1];
prior.transforms.type = 'negLogLogit';
prior.nParams = 1;
