function l = invgammaPriorLogProb(prior, x)

% INVGAMMAPRIORLOGPROB Log probability of inverse gamma prior.
%
% l = invgammaPriorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% invgammaPriorLogProb.m version 1.2





% Compute log prior
D = length(x);
l = D*prior.a*log(prior.b)-D*gammaln(prior.a)-(prior.a+1)*sum(log(x))-prior.b*sum(1./x);
