function l = wangPriorLogProb(prior, x)

% WANGPRIORLOGPROB Log probability of Wang prior.
%
% l = wangPriorLogProb(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% wangPriorLogProb.m version 1.1



% Compute log prior
D = length(x);
l = -prior.M*sum(log(x));
