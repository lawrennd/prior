function prior = normuniPriorParamInit(prior)

% NORMUNIPRIORPARAMINIT Normal uniform prior model's parameter initialisation.
%
% prior = normuniPriorParamInit(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% normuniPriorParamInit.m version 1.1



prior.sigma = 0.1;
prior.width = 2;
prior.transforms.index = [1 2];
prior.transforms.type = 'negLogLogit';
prior.nParams = 2;
