function prior = laplacePriorParamInit(prior)

% LAPLACEPRIORPARAMINIT Laplace prior model's parameter initialisation.
%
% prior = laplacePriorParamInit(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% laplacePriorParamInit.m version 1.1



prior.precision = 1;

prior.transforms.index = [1];
prior.transforms.type = 'negLogLogit';
prior.nParams = 1;
