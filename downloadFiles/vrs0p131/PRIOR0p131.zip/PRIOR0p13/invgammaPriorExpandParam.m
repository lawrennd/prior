function prior = invgammaPriorExpandParam(prior, params)

% INVGAMMAPRIOREXPANDPARAM Expand inverse gamma prior structure from params.
%
% prior = invgammaPriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% invgammaPriorExpandParam.m version 1.2





prior.a = params(1);
prior.b = params(2);
