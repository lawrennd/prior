function prior = priorReadParamsFromFID(prior, FID)

% PRIORREADPARAMSFROMFID Read prior params from C++ written FID.
%
% prior = priorReadParamsFromFID(prior, FID)
%

% Copyright (c) 2005 Neil D. Lawrence
% priorReadParamsFromFID.m version 1.1



lineStr = getline(FID);
tokens = tokenise(lineStr, '=');
if(length(tokens)~=2 | ~strcmp(tokens{1}, 'numParams'))
  error('Incorrect file format.')
end
numParams = str2num(tokens{2});

params = fscanf(FID, '%f\n', numParams);
fhandle = str2func([prior.type 'PriorExpandParam']);
prior = fhandle(prior, params);

