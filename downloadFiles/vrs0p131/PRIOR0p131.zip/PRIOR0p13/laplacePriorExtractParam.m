function [params, names] = laplacePriorExtractParam(prior)

% LAPLACEPRIOREXTRACTPARAM Extract params from Laplace prior structure.
%
% [params, names] = laplacePriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% laplacePriorExtractParam.m version 1.1



params = prior.precision;
if nargout > 1
  names = {'Laplace precision'};
end