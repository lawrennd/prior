function prior = wangPriorParamInit(prior)

% WANGPRIORPARAMINIT Wang prior model's parameter initialisation.
%
% prior = wangPriorParamInit(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% wangPriorParamInit.m version 1.1



prior.M = 1;

prior.transforms.index = [1];
prior.transforms.type = 'negLogLogit';
prior.nParams = 1;
