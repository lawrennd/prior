function g = gammaPriorGradient(prior, x)

% GAMMAPRIORGRADIENT Gradient wrt x of the gamma prior.
%
% g = gammaPriorGradient(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% gammaPriorGradient.m version 1.3



% Compute gradient of prior
g = (prior.a-1)./x-prior.b;
