function [params, names] = gaussianPriorExtractParam(prior)

% GAUSSIANPRIOREXTRACTPARAM Extract params from Gaussian prior structure.
%
% [params, names] = gaussianPriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussianPriorExtractParam.m version 1.3



params = prior.precision;
if nargout > 1
  names = {'Gaussian precision'};
end