function prior = wangPriorExpandParam(prior, params)

% WANGPRIOREXPANDPARAM Expand wang prior structure from params.
%
% prior = wangPriorExpandParam(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% wangPriorExpandParam.m version 1.1



prior.M = params(1);
