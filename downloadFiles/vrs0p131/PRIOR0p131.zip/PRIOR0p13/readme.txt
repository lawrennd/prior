PRIOR software
Version 0.13		Sunday 20 Nov 2005 at 23:13
Copyright (c) 2005 Neil D. Lawrence

This toolbox allows priors to be placed over parameters, at the moment this is used so that MAP solutions can be found for the parameters rather than type-II maximum likelihood. The priors were written for the Null Category Noise Model (see NCNM toolbox) so that an exponential prior could be placed over the process variances. The rest of its functionality has not been tested, so use with care.


MATLAB Files
------------

Matlab files associated with the toolbox are:

gammaPriorExpandParam.m: Expand gamma prior structure from params.
gammaPriorExtractParam.m: Extract params from gamma prior structure.
gammaPriorGradient.m: Gradient wrt x of the gamma prior.
gammaPriorLogProb.m: Log probability of Gamma prior.
gammaPriorParamInit.m: Gamma prior model's parameter initialisation.
gaussianPrior.m: Constrains a parameter to be between 0 and 1.
gaussianPriorExpandParam.m: Expand Gaussian prior structure from param vector.
gaussianPriorExtractParam.m: Extract params from Gaussian prior structure.
gaussianPriorGradient.m: Gradient wrt x of the log Gaussian prior.
gaussianPriorLogProb.m: Log probability of Gaussian prior.
gaussianPriorParamInit.m: Gaussian prior model's parameter initialisation.
invgammaPriorExpandParam.m: Expand inverse gamma prior structure from params.
invgammaPriorExtractParam.m: Extract params from inverse gamma prior structure.
invgammaPriorGradient.m: Gradient wrt x of the log Gaussian prior.
invgammaPriorLogProb.m: Log probability of inverse gamma prior.
invgammaPriorParamInit.m: Inverse gamma prior model's parameter initialisation.
laplacePriorExpandParam.m: Expand Laplace prior structure from param vector.
laplacePriorExtractParam.m: Extract params from Laplace prior structure.
laplacePriorGradient.m: Gradient wrt x of the log Laplace prior.
laplacePriorLogProb.m: Log probability of Laplace prior.
laplacePriorParamInit.m: Laplace prior model's parameter initialisation.
normuniPriorExpandParam.m: Expand Normal uniform prior structure from param vector.
normuniPriorExtractParam.m: Extract params from normal uniform prior structure.
normuniPriorGradient.m: Gradient wrt x of the log normal uniform prior.
normuniPriorLogProb.m: Log probability of a normal uniform.
normuniPriorParamInit.m: Normal uniform prior model's parameter initialisation.
priorCreate.m: Create a prior structure given a type.
priorExpandParam.m: Expand the prior model's parameters from params vector.
priorExtractParam.m: Extract the prior model's parameters.
priorGradient.m: Gradient of the prior with respect to its variables
priorLogProb.m: Log probability of Gaussian prior.
priorParamInit.m: Prior model's parameter initialisation.
priorReadFromFID.m: Read a prior from a C++ written FID.
priorReadParamsFromFID.m: Read prior params from C++ written FID.
priorTest.m: Run some tests on the specified prior.
wangPriorExpandParam.m: Expand wang prior structure from params.
wangPriorExtractParam.m: Extract params from Wang prior structure.
wangPriorGradient.m: Gradient wrt x of the Wang prior.
wangPriorLogProb.m: Log probability of Wang prior.
wangPriorParamInit.m: Wang prior model's parameter initialisation.
