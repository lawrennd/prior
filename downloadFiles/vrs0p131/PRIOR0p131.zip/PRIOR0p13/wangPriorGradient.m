function g = wangPriorGradient(prior, x)

% WANGPRIORGRADIENT Gradient wrt x of the Wang prior.
%
% g = wangPriorGradient(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% wangPriorGradient.m version 1.1



% Compute gradient of prior
g = -prior.M./x;
