function [params, names] = wangPriorExtractParam(prior)

% WANGPRIOREXTRACTPARAM Extract params from Wang prior structure.
%
% [params, names] = wangPriorExtractParam(prior)
%

% Copyright (c) 2005 Neil D. Lawrence
% wangPriorExtractParam.m version 1.1



params = [prior.M];
if nargout > 1
  names = {'M'};
end