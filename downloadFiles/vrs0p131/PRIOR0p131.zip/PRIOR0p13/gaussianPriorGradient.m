function g = gaussianPriorGradient(prior, x)

% GAUSSIANPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
%
% g = gaussianPriorGradient(prior, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussianPriorGradient.m version 1.3



% Compute gradient of prior
g = -prior.precision*x;
