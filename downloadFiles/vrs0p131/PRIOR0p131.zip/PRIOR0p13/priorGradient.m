function g = priorGradient(prior, params)

% PRIORGRADIENT Gradient of the prior with respect to its variables
%
% g = priorGradient(prior, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% priorGradient.m version 1.4


fhandle = str2func([prior.type 'PriorGradient']);
g = fhandle(prior, params);