function [params, names] = invgammaPriorExtractParam(prior)

% INVGAMMAPRIOREXTRACTPARAM Extract params from inverse gamma prior structure.
%
% [params, names] = invgammaPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





params = [prior.a prior.b];
if nargout > 1
  names = {'inv gamma a', 'inv gamma b'};
end