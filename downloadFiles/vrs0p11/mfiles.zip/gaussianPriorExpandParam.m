function prior = gaussianPriorExpandParam(prior, params)

% GAUSSIANPRIOREXPANDPARAM Expand Gaussian prior structure from param vector.
%
% prior = gaussianPriorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





prior.precision = params(1);
