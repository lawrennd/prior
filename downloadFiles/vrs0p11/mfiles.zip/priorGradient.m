function g = priorGradient(prior, params)

% PRIORGRADIENTPARAM Gradient of the prior with respect to its variables
%
% g = priorGradient(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11




g = feval([prior.type 'PriorGradient'], prior, params);