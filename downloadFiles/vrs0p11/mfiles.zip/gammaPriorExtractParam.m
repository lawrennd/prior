function [params, names] = gammaPriorExtractParam(prior)

% GAMMAPRIOREXTRACTPARAM Extract params from gamma prior structure.
%
% [params, names] = gammaPriorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





params = [prior.a prior.b];
if nargout > 1
  names = {'gamma a', 'gamma b'};
end