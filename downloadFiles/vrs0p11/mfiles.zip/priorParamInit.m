function prior = priorParamInit(prior)

% PRIORPARAMINIT Prior model's parameter initialisation.
%
% prior = priorParamInit(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





prior = feval([prior.type 'PriorParamInit'], prior);
