function l = priorLogProb(prior, x)

% PRIORLOGPROB Log probability of Gaussian prior.
%
% l = priorLogProb(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





% Compute log prior
l = feval([prior.type 'PriorLogProb'], prior, x);
