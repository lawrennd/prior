function [params, names] = priorExtractParam(prior)

% PRIOREXTRACTPARAM Extract the prior model's parameters.
%
% [params, names] = priorExtractParam(prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





if nargout < 2
  params = feval([prior.type 'PriorExtractParam'], prior);
else
  [params, names] = feval([prior.type 'PriorExtractParam'], prior);
end


% Check if parameters are being optimised in a transformed space.
if isfield(prior, 'transforms')
  for i = 1:length(prior.transforms)
    index = prior.transforms(i).index;
    params(index) = feval([prior.transforms(i).type 'Transform'], ...
              params(index), 'xtoa');
  end
end