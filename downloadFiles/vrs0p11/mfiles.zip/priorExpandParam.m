function prior = priorExpandParam(prior, params)

% PRIOREXPANDPARAM Expand the prior model's parameters from params vector.
%
% prior = priorExpandParam(prior, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11




if isfield(prior, 'transforms')
  for i = 1:length(prior.transforms)
    index = prior.transforms(i).index;
    params(index) = feval([prior.transforms(i).type 'Transform'], ...
              params(index), 'atox');
  end
end

prior = feval([prior.type 'PriorExpandParam'], prior, params);
