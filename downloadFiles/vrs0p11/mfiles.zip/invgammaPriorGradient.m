function g = invgammaPriorGradient(prior, x)

% INVGAMMAPRIORGRADIENT Gradient wrt x of the log Gaussian prior.
%
% g = invgammaPriorGradient(prior, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:11:41 2004
% PRIOR toolbox version 0.11





% Compute gradient of prior
D = length(x);
g =-(prior.a+1)./x + prior.b./(x.*x);
